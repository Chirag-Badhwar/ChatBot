# Team-Automated-Chatbot
Telegram Chatbot: Kamand Listener which answers Fresher's Queries. This bot uses python,telegram api, google search api, keras to implement the bot. The database is self prepared with the help of freshers in a excel file which is then converted to the required jSon format.
